#!/usr/bin/env python3

class CantConnectException(Exception):
    pass

class CantRegisterException(Exception):
    pass

class CantLoginException(Exception):
    pass

class CantGetPlaylistException(Exception):
    pass
